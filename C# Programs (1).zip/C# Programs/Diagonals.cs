﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            int i, j;
            int n = 3;
            int[,] arr = new int[3, 3] { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } };
            int k = n - 1;
            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 3; j++)
                {
                    Console.Write(arr[i, j] + " ");
                }
                Console.WriteLine();
            }
            for ( i = 0; i < n; i++)
            {
                 j = n - 1 - i;
                for ( k = 0; k < n; k++)
                {
                    if (k == i || k == j)
                        Console.Write(arr[i,k] +" ");

                    else
                        Console.Write("  ");
                }
                Console.WriteLine();
            }


        }
    }
}
