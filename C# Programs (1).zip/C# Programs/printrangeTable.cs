﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp4
{
    class Class1
    {
        static void main1(string[] args)
        {

            int end = int.Parse(Console.ReadLine());
            for (int start = 1; start <= end; start++)
            {
                Console.WriteLine("\n" + " Print {0} Table", start + "\n");
                for (int table = 1; table <= 10; table++)
                {
                    Console.WriteLine(start + " * " + table + " = " + start * table);
                }
            }
        }
    }
}
