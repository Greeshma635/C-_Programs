﻿using System;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {


            //num = 12345		Count the digits of a number : 5
            //num = 456		DigitsCount = 3
           // num = 467       Sum of the digits = 17
           //num = 789       ReverseNumber = 987
          //num = 123       123 is not palindrome number
          // num = 121       121 is a palindrome number

            int a = Convert.ToInt32(Console.ReadLine());
            int rem, sum = 0, rev=0;
            int count = 0;
            int original = a;
            while(a!=0)
            {
                rem = a % 10;
                sum = sum + rem;
                rev = rev * 10 + rem;
                    count++;
                a = a / 10;
            }
            Console.WriteLine("Count the digits of a number : "+count);
            Console.WriteLine(" DigitsCount = " + count);
            Console.WriteLine("Sum of digits is = " + sum);
            Console.WriteLine(" ReverseNumber = " + rev);
            if (original == rev)
            {
                Console.WriteLine(rev + "  is a palindrome number");
            }
            else 
            {
                Console.WriteLine(rev + "  is not palindrome number" ); 
            }
        }
    }
}
