﻿using System;

namespace ConsoleApp4
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 1; i <= 5; i++)
            {
                for (int j = 1; j <= i; j++)
                {
                    Console.Write(i + " ");
                }
                Console.WriteLine();
            }
            for (int l = 4; l >= 1; l--)
            {
                for (int k = 1; k <= l; k++)
                {
                    Console.Write(l + " ");
                }
                Console.WriteLine();
            }
               
            
        }
    }
}

