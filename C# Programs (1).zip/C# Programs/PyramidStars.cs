﻿using System;

namespace ConsoleApp5
{
    class Program
    {
        static void Main(string[] args)
        {
            int i, k, j;
            int n = int.Parse(Console.ReadLine());
            for (i = 1; i <= n; i++)
            {
                for ( k = 1; k <= n - i; k++)
                {
                    Console.Write("  ");
                }
                for ( j = 1; j <= 2*i-1; j++)
                {
                    Console.Write("* ");
                }
                Console.WriteLine();
            }
           for (i = n - 1; i >= 1; i--)
           {
                for ( j = 1; j <= n-i; j++)
                    {
                        Console.Write("  ");
                    }
                    for (k = 1; k <= 2 * i - 1; k++)
                    {
                        Console.Write("* ");
                    }
                Console.WriteLine();
           }
        }
    } 
}

