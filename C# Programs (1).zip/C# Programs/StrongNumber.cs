﻿using System;

namespace ConsoleApp5
{
    class Program
    {
        static void Main(string[] args)
        {
            //num = 145		Given number is a strong numbrer
            int a = int.Parse(Console.ReadLine());
            int sum = 0;
            int str = a;
            while(a!=0)
            {
                int rem = 0,  fact = 1;
                rem = a % 10;
                for(int i= rem; i>=1; i--)
                {
                    fact = fact * i;
                }
                rem = 0;
                a = a / 10; 
                sum = sum + fact;
            }
            if (str == sum)
            {
                Console.WriteLine("Given number is a strong numbrer");
            }
            else
            {
                Console.WriteLine("Given number is not a strong numbrer");
            }
        }
    }
}
