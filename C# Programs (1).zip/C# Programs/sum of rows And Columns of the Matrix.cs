﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class Class1
    {
        static void Main(string[] args)
        {
            int i, j, sum;
            int n = 3;
            int[,] arr = new int[3, 3] { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } };
            int k = n - 1;
            for (i = 0; i < 3; i++)
            {
                sum = 0;
                for (j = 0; j < 3; j++)
                {
                    Console.Write(arr[i, j] + "   ");
                    sum = sum + arr[i, j];
                }
                Console.Write("  ===>  " + sum);
                Console.WriteLine();
            }
            Console.WriteLine();
            for (i = 0; i < 3; i++)
            {
                sum = 0;
                for (j = 0; j < 3; j++)
                {
                    
                    sum = sum + arr[j, i];
                }
                Console.Write(sum + "  ");
            }
        }
    }
}
