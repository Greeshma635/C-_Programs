﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        //num = 3456		Separate the digits of a number 6,5,4,3
      
        static void Main(string[] args)
        {
            int a = Convert.ToInt32(Console.ReadLine());
            int rem, rev=0;
            while (a != 0)
            {
                rem = a % 10;
                rev = rev * 10 + rem;
                a = a / 10;

            }
            while (rev!= 0)
            {
                int j = rev % 10;
                Console.Write(j + ", ");
                rev = rev / 10;
            }
        }
    }
}
