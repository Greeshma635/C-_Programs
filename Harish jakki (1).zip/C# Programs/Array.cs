1)find the max digit of a number ?

using System;
namespace DotNet
{
    class Program
    {
        static void Main()
        {
         int num=152454;
         int max=0;
         while(num>0)
         {
          int digit=num%10;
          if(digit>max)
          {
              max=digit;
          }
          num/=10;
         }
         Console.WriteLine(max);
        }
    }
}

===================================================================
2)find the reverse of a number ?

using System;
namespace DotNet
{
    class Program
    {
        static void Main()
        {
         int num=1342;
         int rev=0;
         while(num>0)
         {
             int digit =num%10;
             rev =rev*10+digit;
             num/=10;
         }
         Console.WriteLine(rev);
        }
    }
}

=========================================================================
3)Check given number is Palindrome or not?

using System;
namespace DotNet
{
    class Program
    {
        static void Main()
        {
         int num=1342;
         int copy=num;
         int rev=0;
         while(num>0)
         {
             int digit =num%10;
             rev =rev*10+digit;
             num/=10;
         }
         if(copy==rev)
         {
         Console.WriteLine("Given Number is a Palindrome");
         }
         else
         {
             Console.WriteLine("Given Number is not a Palindrome");
         }
        }
    }
}

==============================================================================

4)Find the factors of a number ?

if(sum==copy)
           {
               Console.Write("Armstrong");
           }
           else
           {
               Console.Write(" Not A Armstrong");

           }
==================================================================

List of Armstrong Numbers;

using System;
namespace DotNet
{
    class Program
    {
        static void Main()
        {
         for(int j=1;j<=10000;j++)
         {
             int num=j;
           int count=0;
           int sum=0;
          int copy=num;
           while(num>0)
           {
               int digit=num%10;
               count++;
               num/=10;
           }
           num=copy;
           while(num>0)
           {
               int power=1;
               int digit=num%10;
               for(int i=1;i<=count;i++)
               {
                   power= power*digit;
               }
               sum=sum+power;
               num/=10;
           }
           if(sum==j)
           {
               Console.WriteLine(j);
           }
           
         }
        }
    }
}


================================================================================
One Dimentional Array

using System.IO;
using System;

class Program
{
    static void Main()
    {
       int[] arr=new int[3];
       arr[0]=10;
       arr[1]=56;
       arr[2]=76;
       Console.WriteLine(arr[0]);
       Console.WriteLine(arr[1]);
       Console.WriteLine(arr[2]);
       foreach(int k in arr)
       {
           Console.WriteLine(k);
       }
    }
}


==============================================================


using System;
					
public class Program
{
	public static void Main()
	{
		int[,] arr=new int[3,3];
       Console.WriteLine("Enter Array Elements");
       for(int i=0;i<3;i++)
       {
           for(int j=0; j<3;j++)
           {
               arr[i,j]=int.Parse(Console.ReadLine());
           }
       }
		Console.WriteLine("Array elements are");
         for(int i=0;i<3;i++)
           {
             for(int j=0; j<3;j++)
             {	
				 Console.Write("{0}\t",arr[i,j]);
		      }
			 Console.WriteLine();
		    }
	}
}

=========================================================

Methods Concept


using System;
					
public class Program
{
	public static int Reverse(int num)
	{
		int rev=0;
		while(num>0)
		{
		rev=rev*10+num%10;
		num /=10;
		}
		return rev;
	}
	public static int Sum(int num1 ,int num2)
	{
		return num1+num2;
	}
	public static void Main()
	{
		int x=Reverse(145);
		Console.WriteLine(x+"\n");
		
		Console.WriteLine(Reverse(543)+"\n");
		
		Console.WriteLine(Sum(10,20)+ "\n");
		
		int res=Sum(6,9);
		Console.WriteLine(res);
		
			
	}
}

=======================================================================
using System;
					
public class Program
{
	public static int Reverse(int num)
	{
		int rev=0;
		int copy =num;
		while(num>0)
		{
			rev=rev*10+num%10;
			num/=10;
		}
		return rev;
	}
		
	public static bool IsPalindrome(int num)
	{
		
		return num==Reverse(num);
	}
	public static string ListOfPalindrome(int start, int end)
	{
		string res=string.Empty;
		for(int i=start; i<=end; i++)
		{
			if(IsPalindrome(i))
			{
				res +=i+",";
			}
			
		}
		return res.Substring(0,res.Length-1)+".";
	}
	
	public static void Main()
	{
		Console.WriteLine(ListOfPalindrome(10,100));
	}
}










