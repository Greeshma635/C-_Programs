﻿using System;

namespace ConsoleApp2
{
    class Palindrome
    {
        static void Main(string[] args)
        {
            int a = int.Parse(Console.ReadLine());
            int rem, rev=0;
            int original = a;
            while(a!=0)
            {
                for (int j = 1; j <= a; j++)
                {
                    rem = a % 10;
                    rev = rev * 10 + rem;
                    a /= 10;
                }
                if (original == rev)
                {
                    Console.WriteLine("List of palindrome numbers  :" + rev);
                }
            }
          
        }
    }
}
