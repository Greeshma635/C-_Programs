using System;

namespace ConsoleApp3
{
    class Factors
    {
        static void Main(string[] args)
        {
            int a = int.Parse(Console.ReadLine());
            
            int count = 0,sum=0;
            int per = a;
            for(int i = 1; i <= a; i++)
            {
                if(a%i==0)
                {
                    sum = sum + i;
                    count++;
                    Console.Write(i + ", ");
                }
            }
            Console.WriteLine("\n");
            Console.WriteLine("Factors count " + count);
            Console.WriteLine("Sum of factors : " + sum);
            int res = sum - per;
            if(per==res)
            {
                Console.WriteLine(per + " Is a perfect");
            }
            else
            {
                Console.WriteLine(per + " Is not a perfect");
            }
        }
    }
}
