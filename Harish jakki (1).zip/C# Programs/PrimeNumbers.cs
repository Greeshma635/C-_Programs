﻿using System;

namespace ConsoleApp6
{
    class PrimeNumbers
    {
        static void Main(string[] args)
        {
            int start = Convert.ToInt32(Console.ReadLine());
            int end = Convert.ToInt32(Console.ReadLine());
            int ctr;
            for (int num = start; num <= end; num++)
            {
                ctr = 0;

                for (int i = 2; i <= num; i++)
                {
                    if (num % i == 0)
                    {
                        ctr++;
                        break;
                    }
                }

                if (ctr == 0 )
                    Console.WriteLine(num);
            }
        }
    }
}
