﻿using System;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {

            int a = int.Parse(Console.ReadLine());
            for (int j = 1; j <= a; j++)
            {
                int  sum = 0;
                int per = j;
                for (int i = 1; i <j; i++)
                {
                    if (j % i == 0)
                    {
                        sum = sum + i;
                    }
                }
                if (per == sum)
                {
                    Console.WriteLine(per);
                }
            }
        }

        
    }
}
