using System;

namespace ConsoleApp4
{
    class Program
    {
        static void Main(string[] args)
        {

             int num = int.Parse(Console.ReadLine());
          
           int count=0;
           int sum=0;
          int copy=num;
           while(num>0)
           {
               int digit=num%10;
               count++;
               num/=10;
           }
           num=copy;
           while(num>0)
           {
               int power=1;
               int digit=num%10;
               for(int i=1;i<=count;i++)
               {
                   power= power*digit;
               }
               sum=sum+power;
               num/=10;
           }
            if (copy == sum)
            {
                Console.WriteLine("Given number is a Armstrong number  ");
            }
            else
            {
                Console.WriteLine("Given number is not a Armstrong number  ");
            }
        }
    }
}
